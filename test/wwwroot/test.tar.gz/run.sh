#!/bin/sh
exec node index.js